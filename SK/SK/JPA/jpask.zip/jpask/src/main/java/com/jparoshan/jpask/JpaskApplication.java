package com.jparoshan.jpask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaskApplication.class, args);
	}

}
